/* Update updates version length */
ALTER TABLE `#__updates` MODIFY `version` varchar(32) DEFAULT '';
